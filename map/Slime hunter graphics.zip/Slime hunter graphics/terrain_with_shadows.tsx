<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="terrain_with_shadows" tilewidth="16" tileheight="16" tilecount="1536" columns="64">
 <image source="assets/terrain_with_shadows.png" width="1024" height="399"/>
</tileset>
